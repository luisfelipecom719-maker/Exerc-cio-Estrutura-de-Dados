package Metodos;

import java.util.ArrayList;

public class SelectionSort {
    public static void ordenarPorNomeCrescente(ArrayList<Aluno> lista) {
        for (int posiSel = 0; posiSel < lista.size() - 1; posiSel++) {
            int posMenor = posiSel;

            for (int i = posMenor + 1; i < lista.size(); i++) {
                if (lista.get(i).getNome().compareToIgnoreCase(lista.get(posMenor).getNome()) < 0) {
                    posMenor = i;
                }
            }

            if (posMenor != posiSel) {
                Aluno temp = lista.get(posiSel);
                lista.set(posiSel, lista.get(posMenor));
                lista.set(posMenor, temp);
            }
        }
    }
}