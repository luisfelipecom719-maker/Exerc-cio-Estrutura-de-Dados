package Metodos;

public class Aluno {
    private String Nome;
    private int RA;
    private int Idade;
    private String Sexo;
    private double Media;
    private String Resultado;

    public Aluno(String nome, int RA, int idade, String sexo, double media, String resultado) {
        this.Nome = nome;
        this.RA = RA;
        this.Idade = idade;
        this.Sexo = sexo;
        this.Media = media;
        this.Resultado = resultado;
    }

    // Getters
    public String getNome() { return Nome; }
    public int getRA() { return RA; }
    public int getIdade() { return Idade; }
    public String getSexo() { return Sexo; }
    public double getMedia() { return Media; }
    public String getResultado() { return Resultado; }

    @Override
    public String toString() {
        return "Nome: " + Nome + " | RA: " + RA + " | Média: " + Media + " | Status: " + Resultado;
    }
}