package Metodos;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArrayList<Aluno> turma = new ArrayList<>();
        int opcao = 0;

        while (opcao != 5) {
            System.out.println("-".repeat(50));
            System.out.println("MENU DE OPÇÕES");
            System.out.println("-".repeat(50));
            System.out.println("1. Cadastrar Alunos");
            System.out.println("2. Relatório por Nome (Crescente)");
            System.out.println("3. Relatório por RA (Decrescente)");
            System.out.println("4. Relatório de Aprovados (Crescente por Nome)");
            System.out.println("5. Sair");
            System.out.println("-".repeat(50));

            System.out.print("Escolha uma opção: ");
            opcao = teclado.nextInt();
            teclado.nextLine(); // Limpa o buffer do teclado

            switch (opcao) {
                case 1:
                    System.out.println("\n--- Cadastro de Aluno ---");
                    System.out.print("Nome: ");
                    String nome = teclado.nextLine();

                    System.out.print("RA: ");
                    int ra = teclado.nextInt();

                    System.out.print("Idade: ");
                    int idade = teclado.nextInt();
                    teclado.nextLine();

                    System.out.print("Sexo: ");
                    String sexo = teclado.nextLine();

                    System.out.print("Média: ");
                    double media = teclado.nextDouble();
                    teclado.nextLine();

                    // Cálculo lógico exigido pelo sistema
                    String resultado = (media >= 6.0) ? "Aprovado" : "Reprovado";

                    turma.add(new Aluno(nome, ra, idade, sexo, media, resultado));
                    System.out.println("Aluno cadastrado com sucesso!");
                    break;

                case 2:
                    System.out.println("\n--- Relatório por Nome (Crescente) ---");
                    SelectionSort.ordenarPorNomeCrescente(turma);
                    for (Aluno a : turma) {
                        System.out.println(a.toString());
                    }
                    break;

                case 3:
                    System.out.println("\n--- Relatório por RA (Decrescente) ---");
                    QuickSort.ordenarPorRADecrescente(turma, 0, turma.size() - 1);
                    for (Aluno a : turma) {
                        System.out.println(a.toString());
                    }
                    break;

                case 4:
                    System.out.println("\n--- Relatório de Aprovados (Crescente por Nome) ---");
                    // Cria uma lista temporária só com os aprovados
                    ArrayList<Aluno> aprovados = new ArrayList<>();
                    for (Aluno a : turma) {
                        if (a.getResultado().equals("Aprovado")) {
                            aprovados.add(a);
                        }
                    }

                    // Ordena a lista filtrada e exibe
                    BubbleSort.ordenarPorNomeCrescente(aprovados);
                    for (Aluno a : aprovados) {
                        System.out.println(a.toString());
                    }
                    break;

                case 5:
                    System.out.println("Saindo do sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        }
        teclado.close();
    }
}