package Metodos;

import java.util.ArrayList;

public class QuickSort {
    public static void ordenarPorRADecrescente(ArrayList<Aluno> lista, int inicio, int fim) {
        if (inicio < fim) {
            int posicaoPivo = particionar(lista, inicio, fim);
            ordenarPorRADecrescente(lista, inicio, posicaoPivo - 1);
            ordenarPorRADecrescente(lista, posicaoPivo + 1, fim);
        }
    }

    private static int particionar(ArrayList<Aluno> lista, int inicio, int fim) {
        int pivo = lista.get(fim).getRA();
        int i = inicio - 1;

        for (int j = inicio; j < fim; j++) {
            // O sinal de ">" garante a ordem decrescente
            if (lista.get(j).getRA() > pivo) {
                i++;
                Aluno temp = lista.get(i);
                lista.set(i, lista.get(j));
                lista.set(j, temp);
            }
        }
        Aluno temp = lista.get(i + 1);
        lista.set(i + 1, lista.get(fim));
        lista.set(fim, temp);

        return i + 1;
    }
}