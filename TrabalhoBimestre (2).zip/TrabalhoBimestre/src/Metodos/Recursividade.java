package Metodos;

import java.util.ArrayList;

public class Recursividade {
    public static Aluno buscarPorRA(ArrayList<Aluno> lista, int raBuscado, int indice) {
        if (indice >= lista.size()) {
            return null;
        }

        if (lista.get(indice).getRA() == raBuscado) {
            return lista.get(indice);
        }

        return buscarPorRA(lista, raBuscado, indice + 1);
    }

    public static double somarMedias(ArrayList<Aluno> lista, int indice) {
        if (indice >= lista.size()) {
            return 0.0;
        }

        return lista.get(indice).getMedia() + somarMedias(lista, indice + 1);
    }
}