package Metodos;

import java.util.ArrayList;

public class MergeSort {
    public static void ordenarPorMediaDecrescente(ArrayList<Aluno> lista, int inicio, int fim) {
        if (inicio < fim) {
            int meio = (inicio + fim) / 2;

            ordenarPorMediaDecrescente(lista, inicio, meio);
            ordenarPorMediaDecrescente(lista, meio + 1, fim);

            intercalar(lista, inicio, meio, fim);
        }
    }

    private static void intercalar(ArrayList<Aluno> lista, int inicio, int meio, int fim) {
        ArrayList<Aluno> esquerda = new ArrayList<>(lista.subList(inicio, meio + 1));
        ArrayList<Aluno> direita = new ArrayList<>(lista.subList(meio + 1, fim + 1));

        int i = 0, j = 0, k = inicio;

        while (i < esquerda.size() && j < direita.size()) {
            if (esquerda.get(i).getMedia() >= direita.get(j).getMedia()) {
                lista.set(k, esquerda.get(i));
                i++;
            } else {
                lista.set(k, direita.get(j));
                j++;
            }
            k++;
        }

        while (i < esquerda.size()) {
            lista.set(k, esquerda.get(i));
            i++;
            k++;
        }

        while (j < direita.size()) {
            lista.set(k, direita.get(j));
            j++;
            k++;
        }
    }
}
